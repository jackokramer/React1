
import React, { useState } from 'react';
import data from './data';
import List from './List';
import Setups from "./assets/setups/useState"

function App() {
  return <h2>reminder project setup</h2>;
  <Setups/>
}

export default App;
